const post_data = [
    {
        "id": 0,
        "title": "2022 종강 세미나",
        "writer": "김가천",
        "time": "10:20",
        "content": "오늘 종강 세미나가 있을 예정입니다"
    },
    {
        "id": 1,
        "title": "2023 개강 세미나",
        "writer": "나가천",
        "time": "12:15",
        "content": "오늘 개강 세미나가 있을 예정입니다"
    },
    {
        "id": 2,
        "title": "2023 종강 세미나",
        "writer": "다가천",
        "time": "15:16",
        "content": "오늘 종강 세미나가 있을 예정입니다"
    },
    {
        "id": 3,
        "title": "2024 개강 세미나",
        "writer": "라가천",
        "time": "18:00",
        "content": "오늘 개강 세미나가 있을 예정입니다"
    },
    {
        "id": 4,
        "title": "2024 종강 세미나",
        "writer": "마가천",
        "time": "13:34",
        "content": "오늘 종강 세미나가 있을 예정입니다"
    }
];

export default post_data;
