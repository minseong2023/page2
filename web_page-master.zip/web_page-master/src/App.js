import logo from './logo.svg';
import './App.css';
import './detail_css/card_news_details.css';
import './detail_css/post_details.css';
import { useState } from "react";
import card_data from './test_data/test_card';
import post_data from './test_data/test_post';
import { Routes, Route, Link } from 'react-router-dom';

      
    

function App() {

  let [postData, setPostData] = useState(post_data)
  let [cardData, setCardData] = useState(card_data)
  return (
    <div className="News">

      {/* 뉴스페이지 헤더 */}
      <header className="News-header">

        {/* 뉴스 헤더 바  */}
        <div className="News-header-bar">
        
          <div className="News_logo_div"><Link to="/"><img src="/news_image/logo_list/text_logo1.jpg" className="News-logo" /></Link></div>

          {/* 헤더 메뉴 부분 */}
          <div className="News-menu">
          <a href="#" className="News-menu-select" style={{ marginLeft: '10px' }}>동아리 소식</a><p className="News-menu_p_tag">|</p><a href="#" className="News-menu-select">보안 뉴스</a><p className="News-menu_p_tag">|</p><a href="#" className="News-menu-select">CTF 소식</a>
          </div>

          <div className="News_login_div">
            <button className="News_login_button">로그인</button>
          </div>
        </div>
      </header>
      <Routes>
        <Route path="/" element={<MainPage postData={postData} />} />
        <Route path="/cards" element={<MoreCardPage cardData={cardData}/>} />
        <Route path="/posts" element={<MorePostPage postData={postData} />} />
      </Routes>
      
    </div>
  );
}

function MainPage({ postData }) {
  return (
    <>
      <div className="News-left"></div>
      <div className="News-center">
        <div className="News_card_container">
          <Link to="/cards"><input className='more_card' type="button" value="카드뉴스 더보기" /></Link>
          <Card_News postData={postData}/>
          <Card_News postData={postData}/>
          <Card_News postData={postData}/>
          <Card_News postData={postData}/>
        </div>
        <div className="News_post">
          <div className="News_post_search_container">
            <input className="News_post_search_bar" type="text" placeholder="검색..." />
            <Link to="/posts"><input className='more_post' type="button" value="게시글 더보기" /></Link>
          </div>
          <div className="News_post_box">
            <div className="News_post_box_classification" style={{borderBottom: '1px solid black'}}>
              <div className="News_post_content_number">NO</div>
              <div className="News_post_content_title">제목</div>
              <div className="News_post_content_writer">작성자</div>
              <div className="News__post_content_write_time">작성시간</div>
            </div>
            <Post postData={postData[postData.length - 1]}/>
            <Post postData={postData[postData.length - 2]}/>
            <Post postData={postData[postData.length - 3]}/>
            <Post postData={postData[postData.length - 4]}/>
          </div>
        </div>
      </div>
      <div className="News-right"></div>
      <div className="News-footer"></div>
    </>
  );
}

function MorePostPage({ postData }){
  return (
    <div>
      <div className="News-left"></div>
      <div className="News-center" style={ {marginTop : "20px"} }>
        <div className='postHeader'>
          <p className='totalPost'>전체글 보기<input className='writePostButton' type='button' value="글쓰기"/></p>
        </div>
        <div className="News_post_box">
            <div className="News_post_box_classification">
              <div className="News_post_content_number">NO</div>
              <div className="News_post_content_title">제목</div>
              <div className="News_post_content_writer">작성자</div>
              <div className="News__post_content_write_time">작성시간</div>
            </div>
            <Post postData={postData[postData.length - 1]}/>
            <Post postData={postData[postData.length - 2]}/>
            <Post postData={postData[postData.length - 3]}/>
            <Post postData={postData[postData.length - 4]}/>
            <Post postData={postData[postData.length - 5]}/>
        </div>
      </div>
      <div className="News-right"></div>
      <div className="News-footer"></div>
    </div>
  );
}

function MoreCardPage({ cardData }){
  return (
    <div>
      <div className="News-left"></div>
      <div className="News-center" style={ {marginTop : "20px"} }>
        <div className='postHeader'>
          <p className='totalPost'>전체 카드뉴스 보기<input className='writeCardButton' type='button' value="글쓰기"/></p>
        </div>
        <FourLineCards/>
      </div>
      <div className="News-right"></div>
      <div className="News-footer"></div>
    </div>
  );
}

function Card_News() {
  return (
    <div className="News_card_content">
      <div style={{ position: 'relative' }}>
        <div className="News_page_overlay"></div>
        <img src="/news_image/card_news/2024-04-08-17-34-33.jpg" alt="" />
      </div>
    </div>
  )
}

function OneLineCards() {
  return (
    <div className="cards_container">
      <Card_News />
      <Card_News />
      <Card_News />
      <Card_News />
    </div>
  );
}
function FourLineCards() {
  return (
    <div>
      <OneLineCards/>
      <OneLineCards/>
      <OneLineCards/>
      <OneLineCards/>
    </div>
  );
}

function Post(props) {
  return (
    <div className='News_post_box_division'>
      <div className="News_post_content_number">{props.postData.id}</div>
      <div className="News_post_content_title">{props.postData.title}</div>
      <div className="News_post_content_writer">{props.postData.writer}</div>
      <div className="News__post_content_write_time">{props.postData.time}</div>
    </div>
  );
}
export default App;
